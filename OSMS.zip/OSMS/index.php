<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
    <meta name="author" content="Creative Tim">
    <title>OSMS</title>
    <!-- Favicon -->
    <link href="./assets/img/brand/favicon2.png" rel="icon" type="image/png">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- Icons -->
    <link href="./assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
    <link href="./assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
    <!-- Argon CSS -->
    <link type="text/css" href="./assets/css/argon.css?v=1.0.0" rel="stylesheet">
    <!-- custom css -->
    <link type="text/css" href="css/custom.css">
</head>

<body>
    <!-- Sidenav -->
    <!-- Main content -->
    <div class="main-content">
        <!-- Top manubar -->
        <nav class="navbar navbar-top navbar-horizontal navbar-expand-md navbar-dark">
            <div class="container px-4">
                <a class="navbar-brand" href="../index.html">
                    <!-- <img src="../assets/img/brand/white.png"> -->
                    <h1 style="color:white">OSMS</h1>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-collapse-main"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbar-collapse-main">
                    <!-- Collapse header -->
                    <div class="navbar-collapse-header d-md-none">
                        <div class="row">
                            <div class="col-6 collapse-brand">
                                <a href="../index.html">
                                    <img src="../assets/img/brand/blue.png">
                                </a>
                            </div>
                            <div class="col-6 collapse-close">
                                <button type="button" class="navbar-toggler" data-toggle="collapse"
                                    data-target="#navbar-collapse-main" aria-controls="sidenav-main"
                                    aria-expanded="false" aria-label="Toggle sidenav">
                                    <span></span>
                                    <span></span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <!-- Navbar items -->
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link nav-link-icon" href="../index.html">
                                <i class="ni ni-planet"></i>
                                <span class="nav-link-inner--text">Home</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-link-icon" href="../examples/register.html">
                                <i class="ni ni-circle-08"></i>
                                <span class="nav-link-inner--text">Services</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-link-icon" href="requester/requesterLogin.php">
                                <i class="ni ni-key-25"></i>
                                <span class="nav-link-inner--text">Login</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-link-icon" href="../examples/profile.html">
                                <i class="ni ni-single-02"></i>
                                <span class="nav-link-inner--text">Contact</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <?php 
              if(isset($_REQUEST['SendMail']))
              {
               echo  $to="mailtoattaurrahman@gmail.com";
              echo   $name=$_REQUEST['name'];
               echo  $Subject=$_REQUEST['subject'];
               echo $message=$_REQUEST['message'];
              echo   $header="From:smsbitcreatives.epizy.com";
                mail($to, $subject, $message,$header);
               {
                echo "string";
               }
              }
        ?>
        <!-- Header -->
        <div class=" header bg-gradient-primary2 pb-8 pt-5 pt-md-8 ">
            <div class=" container-fluid">
            <div class="header-body">
                <!-- Card stats -->

            </div>
        </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--7">
        <div class="row mt-5">
            <div class="col-xl-8 mb-5 mb-xl-0">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">User Registration</h3>
                            </div>
                        </div>
                    </div>
                    <!-- Registration form -->
                    <?php include_once 'userRegistration.php';?>
                    <!-- end Registration form -->
                </div>
            </div>
            <div class="col-xl-4">
                <div class="card shadow">
                    <div class="table-responsive">
                        <!-- Projects table -->
                        <table class="table align-items-center table-flush">
                            <tbody>

                               <div class="card bg-secondary shadow">
            <div class="card-header bg-white border-0">
              <div class="row align-items-center">
                <div class="col-8">
                  <h3 class="mb-0">Contact Us!</h3>
                </div>
              </div>
            </div>
            <div class="card-body">
              <form method="post">
                <div class="pl-lg-1">
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-username">Name</label>
                        <input type="text" id="input-username" class="form-control form-control-alternative" name="name" placeholder="Username" value="lucky.jesse">
                      </div>
                    </div>
                </div>
            </div>
            <div class="pl-lg-1">
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-username">Email</label>
                        <input type="text" id="input-username" class="form-control form-control-alternative" name="email" placeholder="Username" value="lucky.jesse">
                      </div>
                    </div>
                </div>
            </div>
            <div class="pl-lg-1">
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-username">Subject</label>
                        <input type="text" id="input-username" class="form-control form-control-alternative" name="subject" placeholder="Username" value="lucky.jesse">
                      </div>
                    </div>
                </div>
            </div>
            <div class="pl-lg-1">
                  <div class="row">
                    <div class="col-lg-12">
                       <div class="form-group focused">
                        <label class="form-control-label" for="input-username">Message</label>
                         <textarea rows="4" class="form-control form-control-alternative" placeholder="A few words about you ..." name="message">A beautiful Dashboard for Bootstrap 4. It is Free and Open Source.</textarea>
                    </div>
                </div>
             </div>
             <div class="text-center">
                  <button type="submit" name="SendMail" class="btn btn-primary mt-2">Sign in</button>
                </div>
            </div>
        </form>
            </div>
          </div>
        </tbody>
         </table>
           </div>
             </div>
              </div>
                </div>
        <!-- Footer -->
        <footer class="footer">
            <div class="row align-items-center justify-content-xl-between">
                <div class="col-xl-6">
                    <div class="copyright text-center text-xl-left text-muted">
                        &copy; 2018 <a href="https://www.creative-tim.com" class="font-weight-bold ml-1"
                            target="_blank">Creative Tim</a>
                    </div>
                </div>
                <div class="col-xl-6">
                    <ul class="nav nav-footer justify-content-center justify-content-xl-end">
                        <li class="nav-item">
                            <a href="https://www.creative-tim.com" class="nav-link" target="_blank">Creative Tim</a>
                        </li>
                        <li class="nav-item">
                            <a href="https://www.creative-tim.com/presentation" class="nav-link" target="_blank">About
                                Us</a>
                        </li>
                        <li class="nav-item">
                            <a href="http://blog.creative-tim.com" class="nav-link" target="_blank">Blog</a>
                        </li>
                        <li class="nav-item">
                            <a href="admin/login.php" class="nav-link">Admin</a>
                        </li>
                        <li class="nav-item">
                            <a href="https://github.com/creativetimofficial/argon-dashboard/blob/master/LICENSE.md"
                                class="nav-link" target="_blank">MIT License</a>
                        </li>
                    </ul>
                </div>
            </div>
        </footer>
    </div>
    </div>
    <!-- Argon Scripts -->
    <!-- Core -->
    <script src="./assets/vendor/jquery/dist/jquery.min.js"></script>
    <script src="./assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Optional JS -->
    <script src="./assets/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="./assets/vendor/chart.js/dist/Chart.extension.js"></script>
    <!-- Argon JS -->
    <script src="./assets/js/argon.js?v=1.0.0"></script>
</body>

</html>
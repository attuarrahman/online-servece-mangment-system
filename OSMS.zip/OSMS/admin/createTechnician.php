<?php
session_start();
define('TITLE','Create Technician');
define('PAGE','technician');
include_once('adminincludes/header.php');
include_once('../connection.php');
if(isset($_SESSION['is_adminlogin']))
 {
 	if(isset($_REQUEST['submit']))
 	{
 		if($_REQUEST['name'] == "" ||
 		   $_REQUEST['email'] == "" || 
           $_REQUEST['mobile'] == "" ||
           $_REQUEST['qualifications'] == "" ||
           $_REQUEST['address'] == "" )
 		{
 		  echo "<div class='alert alert-danger mx-4'>All Fields Require</div>";
 		}
 		else{
 			$name=$_REQUEST['name'];
 			$email=$_REQUEST['email'];
 			$mobile=$_REQUEST['mobile'];
 			$qualifications=$_REQUEST['qualifications'];
 			$address=$_REQUEST['address'];
 			$query="INSERT INTO createtechnician (`name`,`email`,`mobile`,`qualifications`, `address`) values('$name','$email','$mobile','$qualifications','$address')";
 			mysqli_query($conn,$query) or die($conn->error);
 			$msg="<div class='alert alert-success mx-4'>Technician Added Successfully</div>";
 			header('location:technician.php?msgsuccess='.$msg);
 		
 		   }
 	    }

 ?>
      <div class="col-xl-8 order-xl-1">
          <div class="card bg-secondary shadow">
            <div class="card-header bg-white border-0">
              <div class="row align-items-center">
                <div class="col-8">
                  <h3 class="mb-0">Add Technician</h3>
               </div>
            </div>
          </div>
         <div class="card-body">
              <form method="POST" action="">
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-username">Name</label>
                        <input type="text" name="name" id="input-username" class="form-control form-control-alternative" placeholder="Username" value="">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-email">Email address</label>
                        <input type="email" name="email" id="input-email" class="form-control form-control-alternative" placeholder="jesse@example.com">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-address">Phone Number</label>
                        <input id="input-address" class="form-control form-control-alternative" placeholder="Home Address" value="" type="number" name="mobile">
                      </div>
                  </div>
                      <div class="col-md-6">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-address">Qulification</label>
                        <input id="input-address" class="form-control form-control-alternative" placeholder="Home Address" value="" type="text" name="qualifications">
                      </div>
                    </div>
                    </div>
                  </div>
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-address">Address</label>
                        <input id="input-address" class="form-control form-control-alternative" placeholder="Home Address" value="" type="text" name="address">
                      </div>
                    </div>
                </div>
            </div>
               <div class="col-5 ml-4">
                  <button type="submit" name="submit" class="btn btn-md" style="color:white;background-color: #B12C2F">Add Techinican</button>
                  <a href="technician.php" type="submit" name="update" class="btn btn-md btn-default mr-4 " style="float: right">Cancel</a>
                </div>
              </form>
            </div>
          </div>
        </div>

<?php  } include_once('adminincludes/footer.php');?>
<?php
ob_start()
 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
    <meta name="author" content="Creative Tim">
    <title><?php echo TITLE; ?></title>
    <!-- Favicon -->
    <link href="../assets/img/brand/favicon2.png" rel="icon" type="image/png">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- Icons -->
    <link href="../assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
    <link href="../assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
    <!-- Argon CSS -->
    <link type="text/css" href="../assets/css/argon.css?v=1.0.0" rel="stylesheet">
    <style>
        
    .viewtext{
        color:black;
    }

    </style>
</head>
<body>
    <!-- Sidenav -->
    <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white d-print-none" id="sidenav-main">
        <div class="container-fluid">
            <!-- Toggler -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main"
                aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- Brand -->
            <a class="navbar-brand pt-0 d-print-none" href="./index.html">
                <img src="../assets/img/brand/favicon2.png" class="navbar-brand-img" alt="...">
            </a>
            <!-- User -->
            <ul class="nav align-items-center d-md-none">
                <li class="nav-item dropdown">
                    <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right"
                        aria-labelledby="navbar-default_dropdown_1">
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">
                        <div class="media align-items-center">
                            <span>
                              <?php
                                    if(session_id() == ""){
                                      session_start();   
                                    }
                                   
                                     include_once('../connection.php');
                                     if(isset($_SESSION['is_adminlogin']))
                                {
                                  $email= $_SESSION['email'];
                                  $query=mysqli_query($conn,"SELECT name FROM adminlogin where email='$email'")or die($conn->error);
                                  echo "<script>alert(query)</script>";
                                     $row=mysqli_fetch_assoc($query);
                                     echo $row['name'];
                                } ?>
                            </span>
                        </div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
                        <div class=" dropdown-header noti-title">
                            <h6 class="text-overflow m-0">Welcome!</h6>
                        </div>
                        <a href="changepassword.php" class="dropdown-item">
                            <i class="ni ni-single-02"></i>
                            <span>My profile</span>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a href="../logout.php" class="dropdown-item">
                            <i class="ni ni-user-run"></i>
                            <span>Logout</span>
                        </a>
                    </div>
                </li>
            </ul>
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                <!-- Collapse header -->
                <div class="navbar-collapse-header d-md-none d-print-none">
                    <div class="row">
                        <div class="col-6 collapse-brand">
                            <a href="./index.html">
                                <img src="../assets/img/brand/favicon2.png">
                            </a>
                        </div>
                        <div class="col-6 collapse-close">
                            <button type="button" class="navbar-toggler" data-toggle="collapse"
                                data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false"
                                aria-label="Toggle sidenav">
                                <span></span>
                                <span></span>
                            </button>
                        </div> 
                    </div>
                </div>
                <!-- Form -->
                <!-- Navigation -->
                <ul id="hiddensidebar" class="navbar-nav d-print-none">
                    <li class="nav-item <?php if(PAGE == 'dashboard') {echo 'active';}?>">
                        <a class="nav-link" href="dashboard.php">
                            <i class="ni ni-tv-2 text-primary "></i> Admin Dashboard
                        </a>
                    </li>
                    <li class="nav-item <?php if(PAGE == 'work'){ echo 'active';} ?>">
                        <a class="nav-link " href="work.php">
                            <i class="ni ni-paper-diploma text-yellow"></i> Work Order
                        </a>
                    </li>
                     <li class="nav-item <?php if((PAGE == 'requests')||(PAGE == 'deleteRequests')){echo 'active';} ?>">
                        <?php 
                        include_once('../connection.php');
                         $query=mysqli_query($conn,"SELECT * FROM submitrequest where request_status='0' ") or die($conn->error);
                        $row= mysqli_num_rows($query);

                        ?>
                        <a class="nav-link " href="requests.php">
                            <i class="ni ni-button-play text-green"></i> Requests
                            <?php if($row > 0) { ?>

                           
                    <span class=" rounded-circle mx-2 pl-2 pr-2 text-white bg-danger">
                 <?php  echo $row;}?>
                </span>
                        </a>
                    </li>
                    <li class="nav-item <?php if(PAGE == 'assets'){echo 'active';} ?>">
                        <a class="nav-link " href="assets.php">
                            <i class="ni ni-basket text-pink"></i> Assets
                        </a>
                    </li>
                    <li class="nav-item <?php if(PAGE == 'technician'){ echo 'active';} ?>">
                        <a class="nav-link " href="technician.php">
                            <i class="ni ni-single-02 text-red"></i> Technician
                        </a>
                    </li>
                    <li class="nav-item <?php if(PAGE == 'sellreport'){ echo 'active'; }?>">
                        <a class="nav-link " href="sellreport.php">
                            <i class="ni ni-single-copy-04 text-brown"></i> Sell Report
                        </a>
                    </li>
                    <li class="nav-item <?php if(PAGE == 'workreport'){ echo 'active'; }?>">
                        <a class="nav-link " href="workreport.php">
                            <i class="ni ni-badge text-orange"></i> Work Report
                        </a>
                    </li>
                    <li class="nav-item <?php if(PAGE == 'changepassword'){ echo 'active'; }?> ">
                        <a class="nav-link  " href="changepassword.php">
                            <i class="ni ni-key-25 text-info"></i> Change Password
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="ni ni-user-run text-success"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Main content -->
    <div id="hidden" class="main-content">
        <!-- Top navbar -->
        <nav class="navbar navbar-top navbar-expand-md navbar-dark d-print-none" id="navbar-main">
            <div class="container-fluid">
                <!-- Brand -->
                <a class="h4 mb-0 text-white text-uppercase d-none d-lg-inline-block" href="./index.html">OSMS</a>
                <!-- User -->
                <ul class="navbar-nav align-items-center d-none d-md-flex">
                    <li class="nav-item dropdown">
                        <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">
                            <div class="media align-items-center">
                                <span class="">
                                    <?php
                                    if(session_id() == ""){
                                      session_start();   
                                    }
                                   
                                     include_once('../connection.php');
                                     if(isset($_SESSION['is_adminlogin']))
                                {
                                  $email= $_SESSION['email'];
                                  $query=mysqli_query($conn,"SELECT name FROM adminlogin where email='$email'")or die($conn->error);
                                  echo "<script>alert(query)</script>";
                                     $row=mysqli_fetch_assoc($query);
                                     echo $row['name'];
                                } ?>
<!--                                     <img alt="Image placeholder" src="../images/mypic.png">
 -->                                </span>
                                <div class="media-body ml-2 d-none d-lg-block">
                                    <span class="mb-0 text-sm  font-weight-bold">
                                        <!-- echo $name = $_SESSION['name']; this will be use for profile -->
                                    </span>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
                            <div class=" dropdown-header noti-title">
                                <h6 class="text-overflow m-0">Welcome!</h6>
                            </div>
                            <a href="changepassword.php" class="dropdown-item">
                                <i class="ni ni-single-02"></i>
                                <span>My profile</span>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="../logout.php" class="dropdown-item">
                                <i class="ni ni-user-run"></i>
                                <span>Logout</span>
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- Header -->
        <div class="header bg-gradient-primary2 pb-6 pt-5 pt-md-2">
        </div>
        <!-- Page content -->
        <br>
<!-- Footer -->
</div>
</div>
<!-- Argon Scripts -->
<!-- Core -->
<script src="../assets/vendor/jquery/dist/jquery.min.js"></script>
<script src="../assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- Optional JS -->
<script src="../assets/vendor/chart.js/dist/Chart.min.js"></script>
<script src="./assets/vendor/chart.js/dist/Chart.extension.js"></script>
<!-- Argon JS -->
<script src="../assets/js/argon.js?v=1.0.0"></script>
<script>
	
	function calculatePrice()
	{   var quantity = $('#quantity').val(); 
		var available_product =$('#available_product').val();   
		if(quantity > available_product)
		{
			var msg='Enter valid quantity';
		 document.getElementById('quantity').value = msg;
		}
		else{
		var total_product = $('#total_product').val();
		var total = total_product * quantity;
		document.getElementById('total_price').value = total;
	}
	}
</script>
</body>

</html>
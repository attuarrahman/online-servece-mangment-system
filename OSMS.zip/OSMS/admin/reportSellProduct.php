<?php
session_start();
define('TITLE','Customer bill');
define('PAGE','assets');
include_once('adminincludes/header.php');
include_once('../connection.php');
if(isset($_SESSION['is_adminlogin']))
{

		 $id=$_SESSION['myid'];
		$query=mysqli_query($conn,"SELECT * FROM selling_product where id='$id'") or die($conn->error);
		if($query == true)
		{
			$row=mysqli_fetch_assoc($query);
			
		
		?>
    <h4 class="ml-3">Check Sell Report</h4>
		<div class="row">
			<div class="col-sm-6 mt-3 mx-6">
          <table class="table table-bordered border-2">
          	  <tbody>
          	  	<h4 class="text-center">Customer Bill</h4>
          		<tr>
          			<td class="font-weight-bold">Product Name</td>
          			<td><?php echo $row['name']; ?></td>
          		</tr>
          		<tr>
          			<td class="font-weight-bold">Customer Name</td>
          			<td><?php echo $row['customer_name']; ?></td>
          		</tr>	
                <tr>
                <td class="font-weight-bold">Customer Number</td>
                <td><?php echo $row['mobile']; ?></td>
              </tr>
          		<tr>
          			<td class="font-weight-bold">Customer Address</td>
          			<td><?php echo $row['customer_address']; ?></td>
          		</tr>	
          		<tr>
          			<td class="font-weight-bold">Each Product Price</td>
          			<td><?php echo $row['selling_price']; ?></td>
          		</tr>	
          		<tr>
          			<td class="font-weight-bold">Number Of Quantity</td>
          			<td><?php echo $row['quantity']; ?></td>
          		</tr>
          		<tr>
          			<td class="font-weight-bold">Date</td>
          			<td><?php echo $row['date']; ?></td>
          		</tr>
          		<tr>
          			<td class="font-weight-bold">Total Price</td>
          			<td ><?php echo $row['total_price']; ?></td>
          		</tr>		
          	</tbody>
          </table>
          <div class="mx-3 mt-2 mb-2 d-print-none">
          	<button class="btn btn-md btn-success" onclick="window.print()">Print</button>
          	<a href="assets.php" class="btn btn-md btn-danger">Close</a>
          </div>
      </div>
  </div>

		<?php
	}
}
 include_once('adminincludes/footer.php');
 ?>
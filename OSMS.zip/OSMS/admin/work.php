<?php
if(session_id() == '')
{
	session_start();
}
define('TITLE','Work');
define('PAGE','work');
include_once('adminincludes/header.php');
include_once('../connection.php'); 
if(isset($_SESSION['is_adminlogin']))
{

 if(isset($_GET['msg']))
         {
         	?> <div class="alert alert-danger mx-4"><?php echo $_GET['msg'];?></div><?php
         }
         $query="SELECT * FROM assign_work";
         $run=mysqli_query($conn,$query);
         if(mysqli_num_rows($run) > 0)
                  { 
    ?>
<div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <h3 class="mb-0">Completed Work Detail</h3>
            </div>
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Status</th>
                    <th scope="col">Contact No</th>
                    <th scope="col">Address</th>
                    <th scope="col">Techinican Name</th>
                    <th scope="col">Date</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <?php 
                  	while($row=mysqli_fetch_assoc($run))
                    {
                 ?>
                <tbody>
                  <tr>
                    <td><?php echo $row['id'];?></td>
                    <td><?php echo $row['name'];?></td>
                    <td><span class="badge badge-dot">
                        <i class="bg-success"></i> completed
                      </span></td>
                    <td><?php echo $row['mobile'];?></td>
                    <td><?php echo $row['address'];?></td>
                    <td><?php echo $row['assign_technician'];?></td>
                    <td><?php echo $row['date'];?></td>
                    <td>
                    	<form action="viewAssignWork.php" method="post">
                    		<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    		<button type="submit" name="view" value="view" class="btn btn-sm btn-success"><i class="fa fa-eye"></i></button>
                    		<button type="submit" name="delete" value="delete" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                    	</form>
                    </td>
                  </tr>
                </tbody>
            <?php }?>
              </table>  
            </div>
          </div>
        </div>
      </div>
  <?php }
    else{
    	?><h3 class="mx-8 mt-3">Record Not found!</h3><?php
    }
  ?>
<?php } include_once('adminincludes/footer.php');?>
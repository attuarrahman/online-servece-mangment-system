<?php

if(session_id() == '')
{
  session_start();
}
ob_start();
define('TITLE','Requests');
define('PAGE','requests');
include_once('adminincludes/header.php');
include_once('../connection.php'); 

              if(isset($_GET['msgsuccess']))
              {
               
                ?><div class="row">
                    <div class="col-8">
                      <div class='alert alert-success mr'>
                        <?php echo $_GET['msgsuccess']; ?></div></div></div>
                        <?php
              }
            
if(isset($_SESSION['is_adminlogin']))
{
	$query=mysqli_query($conn,"SELECT id,name,description,date,time FROM submitrequest where request_status = 0")or die("connection error");
	if(mysqli_num_rows($query) > 0  )
	{
   while($row=mysqli_fetch_assoc($query))
  { 
?>
<div class="row">
 
<div class="col-8"> 
              <div class="card card-stats mb-4 mb-xl-3 ml-4">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0">Rerquester ID: <b class="text-success"><?php echo $row['id']; ?></b></h5>
                      <span>Name: <?php echo $row['name']; ?></span><br>
                      <span>Information: <?php echo $row['description']; ?></span>
                    </div>
                  </div>
                  <p class=" mb-0 text-muted text-sm">
                    <span class="text-success mr-2"><i class="fa fa-arrow-down">Date ..</i><?php echo $row['date']; ?></span>||
                    <span class="text-nowrap">Time<?php echo $row['time']; ?></span>
                  </p>
                </div>
                <br>
                <div class="row align-items-center">
                <div class="col ml-4 mb-2 ">
                   <form action="viewRequestDetail.php" method="post">
                    <input type="hidden" name="id" value=" <?php echo $row['id'];?>">
                    <input type="submit" name="view" class="btn btn-sm btn-primary mb-2 mt--5" value="View Detail">
                    <!--  <input class="btn btn-sm  mb-2 mt--5" style="color: white;background-color:#b12b2e"  type="submit" name="submitdelete"  value="delete"> -->
                 </form>
                </div>
              </div>
              </div>
            </div>
           </div>
           <?php
            }
            }
            else{
              ?>
                  <div class="row">
                    <div class="col-8">
                      <div class="card">
                        <div class="card-header">Notification</div>
                       <div class="card-body">
                      <p><?php echo "Rerquester not Found"; ?></p>
                    </div>
                  </div>
                </div>
              </div>
              <?php
            }
           }
          else {
	     echo "<script>location.href='login.php'</script>";
         }?>

<?php include_once('adminincludes/footer.php');?>
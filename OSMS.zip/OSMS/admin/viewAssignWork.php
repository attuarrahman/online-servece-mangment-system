<?php
session_start();
define('TITLE','Assign Work');
define('PAGE','work');
include_once('adminincludes/header.php');
include_once('../connection.php');
if(isset($_SESSION['is_adminlogin']))
{
	if(isset($_REQUEST['view']))
	{
		$id=$_REQUEST['id'];
		$query=mysqli_query($conn,"SELECT * FROM assign_work where id='$id'") or die($conn->error);
		if($query == true)
		{
			$row=mysqli_fetch_assoc($query);
			
		
		?>
		<div class="row">
			<div class="col-sm-6 mt-3 mx-6">
          <table class="table table-bordered border-2">
          	  <tbody>
          	  	<h4 class="text-center">Assign work detail</h4>
          		<tr>
          			<td class="font-weight-bold">ID</td>
          			<td><?php echo $row['id']; ?></td>
          		</tr>
          		<tr>
          			<td class="font-weight-bold">Name</td>
          			<td><?php echo $row['name']; ?></td>
          		</tr>	
          		<tr>
          			<td class="font-weight-bold">Phone Number</td>
          			<td><?php echo $row['mobile']; ?></td>
          		</tr>	
          		<tr>
          			<td class="font-weight-bold">Adress</td>
          			<td><?php echo $row['address']; ?></td>
          		</tr>	
          		<tr>
          			<td class="font-weight-bold">City</td>
          			<td><?php echo $row['city']; ?></td>
          		</tr>
          		<tr>
          			<td class="font-weight-bold">State</td>
          			<td><?php echo $row['state']; ?></td>
          		</tr>
          		<tr>
          			<td class="font-weight-bold">Email</td>
          			<td ><?php echo $row['email']; ?></td>
          		</tr>
          		<tr>
          			<td class="font-weight-bold">Date</td>
          			<td ><?php echo $row['date']; ?></td>
          		</tr>
          		<tr>
          			<td class="font-weight-bold">Techinican Name</td>
          			<td><?php echo $row['assign_technician']; ?></td>
          		</tr>
          		<tr>
          			<td class="font-weight-bold">Admin Sign</td>
          			<td></td>
          		</tr>
          		<tr>
          			<td class="font-weight-bold">Technician Sign</td>
          			<td></td>
          		</tr>			
          	</tbody>
          </table>
          <div class="mx-3 mt-2 mb-2 d-print-none">
          	<button class="btn btn-md btn-success" onclick="window.print()">Print</button>
          	<a href="work.php" class="btn btn-md btn-danger">Close</a>
          </div>
      </div>
  </div>

		<?php
	}
  }
  if (isset($_REQUEST['delete'])) {
  	$id=$_REQUEST['id'];
  	$query=mysqli_query($conn,"DELETE  FROM assign_work WHERE id='$id'")or die($conn->error);
  	if($query == true)
  	{

  		$msg="Record Deleted successfuly";
  		 header('location:work.php?msg='.$msg);
  	}

  }
}
 include_once('adminincludes/footer.php');
 ?>
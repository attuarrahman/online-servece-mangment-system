<?php 
 session_start();
 define('TITLE' ,'VewDetail Request');
 define('PAGE' ,'deleteRequests');
 include_once('../connection.php');
 include_once('adminincludes/header.php');
 $dirImage="../assets/img/uploads/";
 if(isset($_SESSION['is_adminlogin']))
 {
  if(isset($_REQUEST['view']))
  {
	$id=$_REQUEST['id'];
	$query=mysqli_query($conn,("SELECT * from submitrequest where id = '$id'")) or die("connection error");
	if ($query == true) {
		$row=mysqli_fetch_assoc($query);
	}

  }
  if(isset($_REQUEST['Assign']))
  { 
  	if($_REQUEST['id'] == '' 
       ||$_REQUEST['name'] == ''
       ||$_REQUEST['email'] == ''
       ||$_REQUEST['address'] == ''
       ||$_REQUEST['city'] == ''
       ||$_REQUEST['state'] == ''
       ||$_REQUEST['zipcode'] == ''
       ||$_REQUEST['description'] == ''
       ||$_REQUEST['mobile'] == ''
       ||$_REQUEST['date'] == ''
       ||$_REQUEST['assign_technician'] == '' 
  )
  	{
      echo "field not empty";
  	 
  	}
  	else{
         $id=$_REQUEST['id'];
         $name=$_REQUEST['name'];
         $email=$_REQUEST['email'];
         $address=$_REQUEST['address'];
         $city=$_REQUEST['city'];
         $state=$_REQUEST['state'];
         $zipcode=$_REQUEST['zipcode'];
         $description=$_REQUEST['description'];
         $mobile=$_REQUEST['mobile'];
         $date=$_REQUEST['date'];
         $assign_technician=$_REQUEST['assign_technician'];
         //this query is use to update the status of the request and submitRequest table
  	     $updateQuery=mysqli_query($conn,"UPDATE submitrequest SET request_status= '1' where id='$id'") or die('connection error');
  	     //the query use to insert the record of the requester in separate table
  	     $insertQuery="INSERT INTO assign_work  (`name`, `email`,`address`,  `city`,`state`, `zipcode`, `description`, `mobile`, `date`, `assign_technician`)
         values ('$name','$email','$address','$city','$state','$zipcode',
         '$description', '$mobile','$date','$assign_technician')" or die('error');
         $runQuery=mysqli_query($conn,$insertQuery) or die($conn->error);
  	    if($updateQuery && $runQuery == true)
  	     {
          $msg = "Techinican Assign successfuly";
          header('location:requests.php?msgsuccess='.$msg);
          exit();
	     /*echo "<script>location.href='requests.php?msg='.$message</script>";*/ 	      	
  	      }
  	    else{
  		echo "<script>alert('no')</script>";
  	    }
  	}
 
  }	
}
 else{
	echo "<script>location:href='login.php'</script>";
}
?>
<div class="row">
<div class="col-xl-8 col-md-12 order-xl-1">
    <div class="card bg-secondary shadow ml-4">
        <div class="card-header bg-white border-0">
            <div class="row align-items-center">
                <div class="col-8">
                    <h3 class="mb-0">Requester Info..</h3>
                </div>
                <div class="col-4 text-right"> 
                  <a href="requests.php" style="background-color: #B12B2E; color: white" class="btn btn-sm">View All</a> </div>
            </div>
        </div>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data">
                <div class="pl-lg-4">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group focused">
                                <label class="form-control-label" for="input-username">Requester Id</label>
                                <input type="text" id="input-username" class="form-control form-control-alternative viewtext" required
                                    placeholder="atta.ur.rahman" value="<?php echo $row['id'];?>" name="id">
                                    <input type="hidden" name="request_status" value="<?php echo $row['request_status'];?>">
                            </div>
                          </div>
                         <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-control-label" for="input-text">Name</label>
                                <input type="name" id="input-text" class="form-control form-control-alternative viewtext"value="<?php echo $row['name'];?>" required
                                     name="name">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Address -->
                <div class="pl-lg-4">
                    <div class="row">
                        <div class="col-md-6">
                           <div class="form-group">
                                <label class="form-control-label" for="input-email">Email address</label>
                                <input type="email" id="input-email" class="form-control form-control-alternative viewtext"value="<?php echo $row['email'];?>" required
                                    placeholder="atta@gmail.com" name="email">
                            </div>
                          </div>
                            <div class="col-md-6">
                            <div class="form-group focused">
                                <label class="form-control-label" for="input-address">Address</label>
                                <input id="input-address" class="form-control form-control-alternative viewtext" value="<?php echo $row['address']; ?>" required 
                                    placeholder="islamabad E11/4 mehran coplex" type="text" name="address">
                            </div>
                          </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group focused">
                                <label class="form-control-label" for="input-city">City</label>
                                <input type="text" id="input-city" class="form-control form-control-alternative viewtext" value="<?php echo $row['city']; ?>" required 
                                    placeholder="Isamabad" name="city">
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group focused">
                                <label class="form-control-label" for="input-country">state</label>
                                <input type="text" id="input-country" class="form-control form-control-alternative viewtext" value="<?php echo $row['state']; ?>" 
                                    placeholder="Pakistan" required name="state">
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="form-control-label" for="input-country">Zip code</label>
                                <input type="number" id="input-postal-code"
                                    class="form-control form-control-alternative viewtext" placeholder="Postal code" required  value="<?php echo $row['zipcode']; ?>" 
                                    name="zipcode">
                            </div>
                        </div>
                    </div>
                    <div class="pl-lg-3">
                    <div class="form-group focused viewtext">
                        <label class="form-control-label" for="input-file">Description</label>
                          <textarea rows="4" name="description" required class="form-control form-control-alternative viewtext"> <?php echo $row['description']; ?> </textarea>
                    </div>
                   </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group focused viewtext">
                                <label class="form-control-label" for="input-username">Mobile</label>
                                <input type="text" id="input-username" class="form-control form-control-alternative viewtext" required name="mobile" value="<?php echo $row['mobile']; ?>" 
                                    placeholder="mobile">
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="form-control-label" for="input-email">Date</label>
                                <input type="date" class="form-control form-control-alternative" required  placeholder="1-1-2020"
                                    name="date">
                            </div>
                        </div>
                        
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="form-control-label">Assign Techinican</label>
                                <input type="text" class="form-control form-control-alternative" required placeholder="Techinican Name"
                                    name="assign_technician">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Description -->
                
                <div class="col-6 mx-4 col-xs-6">
                    <input type="submit" name="Assign"  class="btn btn-md btn-md btn-success"
                        value="Assign">
                </div>
            </form>
        </div>
    </div>
                   
</div>
<div class="col-xl-4 col-md-4 order-xl-1">
	 <div class="pl-lg-4 bg-white border-0 shadow">
                    <div class="form-group focused align-items-center pt-4 pl-2 ml-4 pb-4">
                        <label class="form-control-label" for="input-file"></label>
                        <img style="width:250px;height: 200px;" src="<?php echo $dirImage.$row['image']; ?>">
                        <a class="btn btn-sm btn-success align-items-center" target="_blank" href="../assets/img/uploads/<?php echo $row['image'];?>">download</a>
                    </div>
                </div>
            </div>
            </div>
<?php include_once('adminincludes/footer.php'); ?>
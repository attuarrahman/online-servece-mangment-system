<?php
ob_start();
session_start();
define('TITLE','Technician');
define('PAGE','technician');
include_once('adminincludes/header.php');
include_once('../connection.php');
if(session_id() == '')
{
	session_start();
}
if(isset($_SESSION['is_adminlogin']))
{

 if(isset($_GET['msgsuccess']))
         {
         echo $_GET['msgsuccess'];
         }
         $query="SELECT * FROM createtechnician";
         $run=mysqli_query($conn,$query);
         
    ?>
<div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header bg-white border-0">
              <div class="row align-items-center">
                <div class="col-8">
                  <h3 class="mb-0">All technican</h3>
                </div>
                <div class="col-4 text-right">
                  <a href="createtechnician.php" class="btn btn-sm btn-primary">Add Techinican</a>
                </div>
              </div>
            </div>
            <?php if(mysqli_num_rows($run) > 0)
                  { ?>
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Contact No</th>
                    <th scope="col">Address</th>
                    <th scope="col">Qualification</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <?php 
                  	while($row=mysqli_fetch_assoc($run))
                    {
                 ?>
                <tbody>
                  <tr>
                    <td><?php echo $row['id'];?></td>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['email'];?></td>
                    <td><?php echo $row['mobile'];?></td>
                    <td><?php echo $row['address'];?></td>
                    <td><?php echo $row['qualifications'];?></td>
                    <td>
                    	<form action="editTechnician.php" method="post">
                    		<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    		<button type="submit" name="view" value="Edit" class="btn btn-sm btn-success"><i class="fa fa-edit"></i></button>
                    		<button type="submit" name="delete" value="delete" class="btn btn-sm btn-danger mr-5"><i class="fa fa-trash"></i></button>
                    	</form>
                    </td>
                  </tr>
                </tbody>
            <?php }?>
              </table>  
            </div>
          </div>
        </div>
      </div>
  <?php }
    else{
    	?><h3 class="mx-8 mt-3 mb-4">Techinican Record not found</h3><?php
    }
  ?>
<?php } include_once('adminincludes/footer.php');?>

<?php include_once('adminincludes/footer.php'); ?>
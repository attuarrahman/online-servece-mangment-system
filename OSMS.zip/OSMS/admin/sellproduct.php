<?php
session_start();
define('TITLE','sell product');
define('PAGE','assets');
include_once('adminincludes/header.php');
include_once('../connection.php');
if(isset($_SESSION['is_adminlogin']))
 {
 	if(isset($_REQUEST['sell']))
 	{
    $id=$_REQUEST['id'];
    $query=mysqli_query($conn,"SELECT * FROM product where id='$id'")or die($conn->error);
    $row = mysqli_fetch_assoc($query);
  }
    if(isset($_REQUEST['submit']))
    {
      {
 		if ( $_REQUEST['name'] == "" ||
           $_REQUEST['customer_name'] == "" ||
           $_REQUEST['mobile'] == "" ||
           $_REQUEST['customer_address'] == "" ||
           $_REQUEST['available_product'] == "" ||
           $_REQUEST['product_price'] == "" ||
           $_REQUEST['quantity'] == "" ||
           $_REQUEST['total_price'] == "" ||
           $_REQUEST['date'] == "" )
 		{
 		  echo "<div class='alert alert-danger mx-4'>All Fields Require</div>";
 		}
 		else{
       $id=$_REQUEST['id'];
 			 $name=$_REQUEST['name'];
 			 $customer_name=$_REQUEST['customer_name'];
       $mobile=$_REQUEST['mobile'];
 			 $customer_address=$_REQUEST['customer_address'];
       $available_product=$_REQUEST['available_product'];
 			 $product_price=$_REQUEST['product_price'];
       $quantity=$_REQUEST['quantity'];
       $total_price=$_REQUEST['total_price'];
       $date=$_REQUEST['date'];
       $remaningproduct=$available_product - $quantity; //the varable use for the other table that quntity is subtract from the avaliable
 			 $query="INSERT INTO selling_product (`name`,`customer_name`,`mobile`, `customer_address`,`available_product`,`selling_price`, `quantity`, `total_price`, `date`) values('$name','$customer_name','$mobile','$customer_address','$available_product','$product_price','$quantity','$total_price','$date')";
 			 mysqli_query($conn,$query) or die($conn->error);
        if($query == true)
       {
       echo  $report=mysqli_insert_id($conn);
      //this query is use to update the available_product cloumn in the product table
      $_SESSION['myid']=$report;
      header('location:reportSellProduct.php');
    
           mysqli_query($conn,"UPDATE product SET available_product='$remaningproduct' where id='$id'") or die($conn->error);
        }
 		   } 		   
     }
 	  }

 ?>
      <div class="col-xl-8 order-xl-1">
          <div class="card bg-secondary shadow">
            <div class="card-header bg-white border-0">
              <div class="row align-items-center">
                <div class="col-8">
                  <h3 class="mb-0">Customer Billing</h3>
                </div>
                <div class="col-4 text-right">
                  <a href="#!" class="btn btn-sm btn-default">Report</a>
                </div>
              </div>
            </div>
         <div class="card-body">
              <form method="POST" action="">
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-username">Product Name</label>
                        <input type="text" name="name" id="input-username" class="form-control form-control-alternative" placeholder="Username" 
                        value="<?php if(isset($row['name'])){
                        echo $row['name']; }?>" readonly>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-text">Customer Name</label>
                        <input type="input" name="customer_name" id="input-text" class="form-control form-control-alternative">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-md-4">
                        <div class="form-group focused">
                        <label class="form-control-label" for="input-address">Phone Number</label>
                        <input class="form-control form-control-alternative" placeholder="Phone Number" type="text" name="mobile">                        
                      </div>
                     </div>
                    <div class="col-md-4">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-text">Custmer Address</label>
                        <input id="input-number" class="form-control form-control-alternative"  value="" type="text" name="customer_address">
                      </div>
                   </div>                      
                      <div class="col-md-4">
                        <div class="form-group focused">
                        <label class="form-control-label" for="input-address">Available Product</label>
                        <input class="form-control form-control-alternative" placeholder="Home Address" value="<?php echo $row['available_product'];?>" type="text" name="available_product" id="available_product" readonly>                        
                      </div>
                     </div>
                    </div>
                  </div>
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-address">Product/Price</label>
                         <input class="form-control form-control-alternative"
                         value="<?php if(isset($row['selling_price'])){echo $row['selling_price'];} ?>"
                          id="total_product" type="text" name="product_price" readonly>
                    </div>
                  </div>
                <div class="col-md-6">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-address">Quantity</label>
                        <input class="form-control form-control-alternative" type="text" name="quantity" id="quantity" onkeyup="calculatePrice()">
                      </div>
                    </div>
                  </div>
                </div>
              <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-address">Total Price</label>
                        <input class="form-control form-control-alternative" value="" type="text" name="total_price"  id="total_price" readonly>
                       </div>
                     </div>
                    <div class="col-md-6">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-address">Date</label>
                        <input class="form-control form-control-alternative" value="" type="date" name="date">
                      </div>
                    </div>
                  </div>
                </div>
               <div class="col-5 ml-4">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="submit" class="btn btn-md" style="color:white;background-color: #B12C2F">Submit</button>
                  <a href="assets.php" type="submit" name="update" class="btn btn-md btn-default mr-6" style="float: right">Cancel</a>
                </div>
              </form>
            </div>
          </div>
        </div>
<?php  } include_once('adminincludes/footer.php');?>
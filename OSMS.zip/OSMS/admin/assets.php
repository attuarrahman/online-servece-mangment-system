<?php 
if(session_id() == '')
{
	session_start();
}
define('TITLE','Assets');
define('PAGE','assets');
include_once('adminincludes/header.php');
include_once('../connection.php'); 

if(isset($_SESSION['is_adminlogin']))
{

 if(isset($_GET['msgsuccess']))
         {
         echo $_GET['msgsuccess'];
         }
         $query="SELECT * FROM product";
         $run=mysqli_query($conn,$query);
         
    ?>
<div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header bg-white border-0">
              <div class="row align-items-center">
                <div class="col-8">
                  <h3 class="mb-0">All Product</h3>
                </div>
                <div class="col-4 text-right">
                  <a href="createassets.php" class="btn btn-sm btn-primary">Add New Product</a>
                </div>
              </div>
            </div>
            <?php if(mysqli_num_rows($run) > 0)
                  { ?>
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">purchase Date</th>
                    <th scope="col">Available Product</th>
                    <!-- <th scope="col">total</th> -->
                    <th scope="col">Original Price/product</th>
                    <th scope="col">Selling Price/product</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <?php 
                  	while($row=mysqli_fetch_assoc($run))
                    {
                 ?>
                <tbody>
                  <tr>
                    <td><?php echo $row['id'];?></td>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['date_of_purchase'];?></td>
                    <td><?php echo $row['available_product'];?></td>
                    <!-- <td><?php echo $row['total_product'];?></td> -->                    
                    <td><?php echo $row['original_price'];?></td>
                    <td><?php echo $row['selling_price'];?></td>
                    <td>
                    	<form action="editAssets.php" method="post">
                    		<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    		<button type="submit" name="view" value="Edit" class="btn btn-sm btn-success"><i class="fa fa-edit"></i></button>
                    		<button type="submit" name="delete" value="delete" class="btn btn-sm btn-danger ml-2"><i class="fa fa-trash "></i></button>
                      </form>
                        <form action="sellproduct.php" method="post" >
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <button type="submit" name="sell" value="sell" class="btn btn-sm ml-7 mx mt--5" style="background-color: yellow"><i class="fa fa-handshake"></i></button>
                    	</form>
                    </td>
                  </tr>
                </tbody>
            <?php }?>
              </table>  
            </div>
          </div>
        </div>
      </div>
  <?php }
    else{
    	?><h3 class="mx-8 mt-3 mb-4">Product is not avaliable in warehouse</h3><?php
    }
  ?>
<?php } include_once('adminincludes/footer.php');?>
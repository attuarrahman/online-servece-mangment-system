
<?php define('TITLE', 'Dashboard');
define('PAGE' , 'dashboard'); ?>
<?php session_start();
include_once ('adminincludes/header.php');
include_once ('../connection.php');
$query="SELECT max(id) FROM submitrequest";
$run=mysqli_query($conn,$query);
$row=mysqli_fetch_row($run);
$submitrequest=$row[0];
$assginWork=mysqli_query($conn,"SELECT * FROM assign_work")or die($conn->error);
$countwork=mysqli_num_rows($assginWork);
$assgintechnician=mysqli_query($conn,"SELECT * FROM createtechnician")or die($conn->error);
$assgintechnician=mysqli_num_rows($assgintechnician);
?>


<div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
            <div class="col-xl-4 col-lg-7">
              <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0 mt-2">Request Received</h5>
                      <span class="h2 font-weight-bold mb-0"><?php echo $submitrequest; ?></span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                        <i class="fas fa-chart-bar"></i>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5 mb-0 text-muted text-sm">
                    <a class="text-success mr-2" href="requests.php">View</a>
                    <span class="text-nowrap">Since last month</span>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-lg-7">	
              <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0 mt-2">Assigned Work</h5>
                      <span class="h2 font-weight-bold mb-0"><?php echo $countwork; ?></span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-warning text-white rounded-circle shadow">
                        <i class="fas fa-chart-pie"></i>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5 mb-0 text-muted text-sm">
                    <a class="text-success mr-2" href="work.php">View</a>
                    <span class="text-nowrap">Since last week</span>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-lg-7">
              <div class="card card-stats mb-4 mb-xl-0">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0 mt-2">No of Technician</h5>
                      <span class="h2 font-weight-bold mb-0"><?php echo $assgintechnician;?></span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-yellow text-white rounded-circle shadow">
                        <i class="fas fa-users"></i>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5 mb-0 text-muted text-sm">
                    <a class="text-success mr-2" href="technician.php">View</a>
                    <span class="text-nowrap">Since yesterday</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
       <br>	<br>
       <?php if(isset($_REQUEST['id'])) 
       {
        $id=$_REQUEST['id'];
        $query=mysqli_query($conn,"DELETE FROM userregistration where id='$id'") or die($conn->error);
        if($query == true)
        {
          $deleteMsg="Record Deleted Successfully";
        }
       }

        if(isset($deleteMsg))
              {
               
                ?><div class="row">
                    <div class="col-12">
                      <div class='alert alert-danger mr'>
                        <?php echo $deleteMsg; ?></div></div></div>
                        <?php
              }?>
        <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0 bg-dark">
              <h3 class="mb-0 text-white">List of Register Requester</h3>
            </div>
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">Requester Id</th>
                    <th scope="col">name</th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                    <th scope="col">email</th>
                    
                    <th scope="col">Action</th>                    
                  </tr>
                </thead>
                <?php 
                 if(isset($_SESSION['is_adminlogin']))
                 {
                 	 $query=mysqli_query($conn,('SELECT id,name,email from userregistration')) or die("connection error");
                  if($query==true){
                  	while($row = mysqli_fetch_assoc($query))
                  	{
                       
                  	?>

               
                <tbody>
                  <tr>
                    <td>
                      <?php echo $row['id'];?>
                    </td>
                    <td>
                    	<?php echo $row['name'];?>
                    </td>
                    <td> <!-- empty td --></td>
                    <td></td>
                    <td>
                    	<?php echo $row['email'];?>
                    </td>
                    <td>
                      <form>
                        <input type="hidden" name="id" value="<?php echo $row['id'];?>">
                        <button type="submit" class="btn btn-sm btn-danger" name="submit"><i class="fa fa-trash"></i></button>
                      </form>
                    </td>                   
                  </tr>
                </tbody>
                <?php }             
                  	
                  }
                  else{
                  	echo "No Record found";
                  }
              }
              else
              	echo "<script>location.href='login.php'</script>";
                 ?>
              </table>
            </div>
          </div>
        </div>
      </div>
   </div>   <!-- close of container fluied -->
<?php include_once 'adminincludes/footer.php';?>
<?php
session_start();
define('TITLE','Work Report');
define('PAGE','workreport');
include_once('adminincludes/header.php'); 
include_once('../connection.php');

if(isset($_SESSION['is_adminlogin']))
{
 ?>
       <h4 class="ml-3">Check work Report</h4>
      <form method="post" class="from-row">
         <div class="row">
	       <div class="col-md-3">
		     <div class="form-group">
		    <input type="date" name="start_date" class="form-control">
	      </div>
      </div>
      <h2>To</h2>
	  <div class="col-md-3">
		<div class="form-group">
		 <input type="date" name="end_date" class="form-control">
	       </div>
	    </div>
	   <div class="col-md-4">
      <div class="form-group">
		<input type="submit" name="submit" value="serach" class="btn btn-md btn-default">
	   </div>
	 </div>
  </div>
</form>

                <?php 
                  	if(isset($_REQUEST['submit']))
                    { 
    	               $start_date=$_REQUEST['start_date'];
    	               $end_date=$_REQUEST['end_date'];
    	               $query=mysqli_query($conn,"SELECT * FROM assign_work where date BETWEEN '$start_date' AND '$end_date'") or die($conn->error);
    	               if(mysqli_num_rows($query) > 0)
    	            {
    	            	?>
                    	<div class="row">
                        <div class="col">
                        <div class="card shadow">
                        <div class="card-header border-0">
                        <h3 class="mb-0">Sell Report</h3>
                      </div>
                       <div class="table-responsive">
                      <table class="table align-items-center table-flush">
                       <thead class="thead-light">
                            <tr>
                              <th scope="col">Id</th>
                              <th scope="col">Name</th>
                              <th scope="col">Technican Email</th>
                              <th scope="col">address</th>
                              <th scope="col">Techinican Name</th>
                              <th scope="col">Date</th>
                   <!--  <th scope="col">Action</th> -->
                           </tr>
                        </thead>
                    	<?php
    	            while($row=mysqli_fetch_assoc($query))
                    {

                 ?>
                <tbody>
                  <tr>
                    <td><?php echo $row['id'];?></td>
                    <td><?php echo $row['name'];?></td>
                    <td><span class="badge badge-dot">
                        <i class="bg-success"></i> completed
                      </span></td>
                    <td><?php echo $row['email'];?></td>
                    <td><?php echo $row['address'];?></td>
                    <td><?php echo $row['city'];?></td>
                    <td><?php echo $row['mobile'];?></td>
                    <td><?php echo $row['assign_technician'];?></td>
                    <td><?php echo $row['date'];?></td>
                    <!-- <td>
                    	<form action="viewAssignWork.php" method="post">
                    		<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    		<button type="submit" name="view" value="view" class="btn btn-sm btn-success"><i class="fa fa-eye"></i></button>
                    		<button type="submit" name="delete" value="delete" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                    	</form>
                    </td> -->
                  </tr>
                </tbody>
            <?php      }
    	           
    	            }
    	            else{
    	            	echo "<div class='ml-4'>Selling Detail Not found!</div>";
    	            }
    	
    	
    }?>
              </table>  
            </div>
          </div>
        </div>
      </div>
<?php
 

}
else
{
	echo "<script>location.href='login.php'</script>";
}

?>
<?php include_once('adminincludes/footer.php');?>
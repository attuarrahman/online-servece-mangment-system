<?php
session_start();
define('TITLE','Create Technician');
define('PAGE','technician');
include_once('adminincludes/header.php');
include_once('../connection.php');
if(isset($_SESSION['is_adminlogin']))
 {
   

 	if(isset($_REQUEST['view']))
 	{
      $id=$_REQUEST['id'];
      $query=mysqli_query($conn,"SELECT * FROM createtechnician where id='$id'") or die($conn->error);
      if($query == true)
      {
        $row=mysqli_fetch_assoc($query);

      }
    }
  if(isset($_REQUEST['update']))
  {
 	    echo $id=$_REQUEST['id'];
 			echo $name=$_REQUEST['name'];
 			echo $email=$_REQUEST['email'];
 			echo $mobile=$_REQUEST['mobile'];
 			echo $qualifications=$_REQUEST['qualifications'];
 			echo $address=$_REQUEST['address'];
 			$query="UPDATE createtechnician SET `name`='$name',`email`='$email', `mobile`='$mobile',`qualifications`='$qualifications',`address`='$address' where id='$id'";
      $run=mysqli_query($conn,$query);
      if($run == true){
          $msg="<div class='alert alert-success mx-4'>Technician Record Updated Successfully</div>";
          header('location:technician.php?msg='.$msg);
      } 
      else{
        echo "not inserted";
      } 
 		
 		
 		   }
     if(isset($_REQUEST['delete'])) 
     {
      $id=$_REQUEST['id'];
      $query="DELETE FROM createtechnician where id='$id'";
      mysqli_query($conn,$query);
       $msg="<div class='alert alert-danger mx-4'>Technician Record Deleted Successfully</div>";
          header('location:technician.php?msgsuccess='.$msg);   
     } 
 ?>
      <div class="col-xl-8 order-xl-1">
          <div class="card bg-secondary shadow">
            <div class="card-header bg-white border-0">
              <div class="row align-items-center">
                <div class="col-8">
                  <h3 class="mb-0">Add Technician</h3>
               </div>
            </div>
          </div>
         <div class="card-body">
              <form method="POST" action="">
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-username">Name</label>
                        <input type="text" name="name" id="input-username" class="form-control form-control-alternative" placeholder="Username" value="<?php echo $row['name'];?>">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-email">Email address</label>
                        <input type="email" name="email" id="input-email" class="form-control form-control-alternative" placeholder="jesse@example.com" value="<?php echo $row['email'];?>">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-address">Phone Number</label>
                        <input id="input-address" class="form-control form-control-alternative" placeholder="Home Address" value="<?php echo $row['mobile'];?>" type="number" name="mobile">
                      </div>
                  </div>
                      <div class="col-md-6">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-address">Qulification</label>
                        <input id="input-address" class="form-control form-control-alternative" placeholder="Home Address" value="<?php echo $row['qualifications'];?>" type="text" name="qualifications">
                      </div>
                    </div>
                    </div>
                  </div>
                <div class="pl-lg-4">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-address">Address</label>
                        <input id="input-address" class="form-control form-control-alternative" placeholder="Home Address" value="<?php echo $row['address'];?>" type="text" name="address">
                      </div>
                    </div>
                </div>
            </div>
               <div class="col-5 ml-4">
                <input type="hidden" value="<?php echo $row['id']; ?>" name="id">
                  <button type="submit" name="update" class="btn btn-md " style="color:white;background-color: #B12C2F">Update Techinican</button>
                  <a href="technician.php" type="submit" name="update" class="btn btn-md btn-default mr-3 " style="float: right">Cancel</a>
                </div>
              </form>
            </div>
          </div>
        </div>

<?php  } include_once('adminincludes/footer.php');?>
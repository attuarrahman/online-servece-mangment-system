<?php include_once 'connection.php';
// session_start();
if (isset($_POST['Submit'])) {
    //  checking empty field
    if (($_REQUEST['name']) == "" || 
        ($_REQUEST['email']) == "" || 
        ($_REQUEST['password'] == ""))
         {
        $Msg = '<div class="alert alert-danger">All fields is require</div>';
         }
    // Checking email
    else {
        $query = mysqli_query($conn, "SELECT email FROM userRegistration WHERE email='" . $_REQUEST['email'] . "'");
        if (mysqli_num_rows($query) > 0) {
            $Msg = '<div class="alert alert-warning">Email already Register</div>';
        }
        // mysqli_real_escape_string this
        //trim function is use to remove the whitespace trim
        // function is use to enter specila characher in database like admin's
        else {
            $name = mysqli_real_escape_string($conn, trim($_REQUEST['name']));
            $email = mysqli_real_escape_string($conn, trim($_REQUEST['email']));
            $password = mysqli_real_escape_string($conn, $_REQUEST['password']);
            $query = mysqli_query($conn, "INSERT INTO userregistration (name,email,password) values('$name','$email','$password')");
            // successfuly  created account
            if ($query == true) {
                $Msg = '<div class="alert alert-success">Your account is successfuly created</div>';
            } else {
                $Msg = '<div class="alert alert-danger">Your account is not created</div>';
            }
        }
    }

}
?>
<div class="col-lg-10 col-md-8">
    <div class="card bg-secondary shadow border-0">
        <div class="card-body px-lg-5 py-lg-5">
            <div class="text-center text-muted mb-4">
                <small>User SignUp Form</small>
                <hr>
            </div>
            <!-- error message show -->
            <?php if (isset($Msg)) {
    echo $Msg;
}?>
            <!-- end error message -->
            <form role="form" method="post" action="">
                <div class="form-group">
                    <div class="input-group input-group-alternative mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="ni ni-hat-3"></i></span>
                        </div>
                        <input class="form-control" placeholder="Name" type="text" name="name">
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group input-group-alternative mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                        </div>
                        <input class="form-control" placeholder="Email" type="email" name="email">
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group input-group-alternative">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                        </div>
                        <input class="form-control" placeholder="Password" type="password" name="password">
                    </div>
                </div>
                <div class="text-muted font-italic"><small>password strength: <span
                            class="text-success font-weight-700">strong</span></small></div>
                <div class="row my-4">
                    <div class="col-12">
                        <div class="custom-control custom-control-alternative custom-checkbox">
                            <input class="custom-control-input" id="customCheckRegister" type="checkbox">
                            <label class="custom-control-label" for="customCheckRegister">
                                <span class="text-muted">I agree with the <a href="#!">Privacy
                                        Policy</a></span>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="text-center">
                    <button type="Submit" name="Submit" style="background-color:#b12b2e;border-color:#b12b2e"
                        class="btn btn-success mt-4">Create
                        account</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- end Registration form -->
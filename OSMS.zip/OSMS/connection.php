<?php
$conn = mysqli_connect('localhost', 'root', '', 'osms_db');

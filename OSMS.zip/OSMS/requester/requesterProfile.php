<?php
require_once '../connection.php';
session_start();
define('TITLE', 'Requester Profile');
define('PAGE', 'requesterProfile');
if (isset($_SESSION['is_login'])) {
    $email = $_SESSION['email'];
} else {
    header('Location:requesterLogin.php');
}

$query = mysqli_query($conn, "SELECT name,email FROM userregistration Where email='$email' ");
if ($query == true) {
    while ($row = mysqli_fetch_assoc($query)) {
        $name = $row['name'];
        $email = $row['email'];
    }
    if (isset($_REQUEST['submit'])) {
        if ($_REQUEST['name'] == "") {
            $msg = '<div class="alert alert-warning">Field is require</div';
        } else {
            $name = mysqli_escape_string($conn, trim($_REQUEST['name']));
            $query = mysqli_query($conn, "UPDATE userregistration SET name='$name' WHERE email='" . $email . "'");
            if ($query == true) {
                $msg = '<div class="alert alert-success">Your Profile is successfuly updated!</div>';
            }

        }

    }
}

?>
<?php include_once 'includes/header.php';?>
<!-- Page content -->
<br>
<div class="col-xl-8 order-xl-1">
    <div class="card bg-secondary shadow">
        <div class="card-header bg-white border-0">
            <div class="row align-items-center">
                <div class="col-8">
                    <h3 class="mb-0">My account</h3>
                </div>

            </div>
        </div>
        <div class="card-body">
            <form action="" method="POST">
                <!-- error mesage -->
                <?php if (isset($msg)) {
    echo $msg;
}?>
                <h6 class="heading-small text-muted mb-4 mx-4">User information</h6>
                <div class="pl-lg-4">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-control-label" for="input-email">Email
                                    address</label>
                                <input type="email" id="input-email" class="form-control form-control-alternative"
                                    placeholder="jesse@example.com" disabled value="<?php echo $email ?>
                                           " name="email">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group focused">
                                <label class="form-control-label" for="input-username">Username</label>
                                <input type="text" id="input-username" class="form-control form-control-alternative"
                                    placeholder="Username" value="<?php echo $name ?>" name="name">
                            </div>
                        </div>
                        <div class="col-4">
                            <button type="Submit" style="background-color:#b12b2e;color:white" name="submit"
                                class="btn btn-sm ">Update</button>
                        </div>
                    </div>
            </form>
        </div>
    </div>
</div>
<!-- Footer -->
<?php include_once 'includes/footer.php';?>
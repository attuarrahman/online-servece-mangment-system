<?php
if(session_id() == "")
{
	session_start();
}
include_once '../connection.php';
// define titel here
define('TITLE', 'Check status');
//define active class
define('PAGE', 'checkstatus');
//include header
include_once 'includes/header.php';
if(isset($_SESSION['is_login']))
{
  ?>
    <div class="row">
	  <div class="col-sm-5 mt-5 mx-3">
		<form method="post">
          <div class="from-group form">          
              <label for="checkid">Check Status</label>
              <input class="form-control" placeholder="Enter your email" type="email" name="email">
            </div>
            <button  name="submit" name="submit" class="btn btn-m btn-success mt-3">Search</button>
        </form>
       </div>
     </div>
    <?php if(isset($_REQUEST['submit'])) 
     { 
     	$email=$_REQUEST['email'];
     	
     
     	$query=mysqli_query($conn,"SELECT * FROM assign_work where email='$email'");
       $row=mysqli_fetch_assoc($query);
       if(mysqli_num_rows($query) > 0)
       {
    ?>
<div class="row">
	<div class="col-sm-7 mt-5 mx-4">
		
		<h3 class="text-center">Assign Work Details</h3>
		<table class="table table-bordered">
			<thead class="thead-light">
				<tr>
					<th>ID</th>
					<th>Email</th>
					<th>Mobile</th>
					<th>Date</th>
					<th>Techinican Name</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><?php echo $row['id']; ?></td>
					<td><?php echo $row['email']; ?></td>
					<td><?php echo $row['mobile']; ?></td>
					<td><?php echo $row['date']; ?></td>
					<td><?php echo $row['assign_technician']; ?></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>

     <?php }
       else{
	     echo "<div class='row'>
	          <div class='col-sm-7 mt-5 mx-4'>
              <h3 class='text-center'>Record Not Found!</h3>
               </div>
               <div>
              ";
      }
  /*else{
   	echo "<div class='alert alert-success'>enter valide</div>";
   }*/

    }
}
else{
	echo "<script>location.href='requesterLogin.php'</script>";
}
?>
<!-- include footer -->
<?php include_once 'includes/footer.php';?>
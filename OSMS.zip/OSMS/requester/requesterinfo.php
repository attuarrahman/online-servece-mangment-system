<?php session_start();
define('TITLE', 'Requester Info');
define('PAGE', 'submitrequest');?>
<?php include_once '../connection.php';?>
<?php include_once 'includes/header.php';?>
<?php
if (isset($_SESSION['is_login'])) {
    $email = $_SESSION['email'];
} else {
    echo "<script>location.href='requesterLogin.php'</script>";

}
$query = "SELECT * FROM submitrequest WHERE email= '$email'";
$runQuery = mysqli_query($conn, $query);
?>
<div class="row mt-5 mx-1 ">
    <div class="col-md-12">
        <div class="card shadow">
            <div class="table-responsive ">
                <table class="table align-items-center table-white  ">
                    <thead style="background-color:#af2b44;color:white">
                        <tr class="d-print-none"> 
                            <!-- the d-print-none class is use to hide bootstrap usning onclik=("window.print") -->
                            <th scope="col">Imge</th>
                            <th scope="col">name</th>
                            <th scope="col">Status</th>
                            <th scope="col">date || time</th>
                            <th scope="col">descrition</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
<?php  
if ($runQuery == true) {
    while($row = mysqli_fetch_assoc($runQuery))
       {
    
?>
                        <tr>
                            <th scope="row">
                                <div class="media align-items-center">
                                    <a href="#" class="avatar rounded-circle mr-3">
                                        <img alt="Image placeholder" src="../assets/img/uploads/<?php echo $row['image']; ?>">
                                    </a>
                                </div>
                            </th>
                            <td>
                                <?php echo $row['name']; ?>
                            </td>
                            <td>
                                <span class="badge badge-dot mr-4 d-print-none">
                                    <i class="bg-warning"></i> pending
                                </span>
                            </td>
                            <td>
                                <?php echo ($row['date']); ?>||<?php echo ($row['time']); ?>
                            </td>
                            <td>
                                <?php echo $row['description'] ?>
                            </td>
                            <td class="text-right">
                                <div class="d-flex justify-content-between">
                               
                                <a href="#" onclick="window.print()" class="btn btn-sm btn-default float-right d-print-none">print</a>
                                 </div>
                                   <!--  <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                        <a class="dropdown-item" onclick="window.print()">print</a>
                                        <a class="dropdown-item" href="#">Another action</a>
                                        <a class="dropdown-item" href="#">Something else here</a>
                                    </div> -->
                              
                            </td>                       
                        </tr>
            <?php  } }?>
                    </tbody>

                </table>
                <br>
                
                <br>
            </div>
            <br>
        </div>
    </div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<?php include_once 'includes/footer.php';?>
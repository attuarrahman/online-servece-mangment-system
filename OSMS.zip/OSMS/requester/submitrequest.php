<?php session_start();
define('TITLE', 'Submit Request');?>
<?php define('PAGE', 'submitrequest');?>
<?php include_once '../connection.php'?>
<?php include_once 'includes/header.php'?>
<?php
if (isset($_SESSION['is_login'])) {
    $email = $_SESSION['email'];
} else {
    echo "<script>location.href='requesterLogin.php'</script>";

}
if (isset($_REQUEST['submit'])) {
    if (($_REQUEST['name'] == "")
        ||  ($_REQUEST['request_status'] == "")
        || ($_REQUEST['email'] == "")
        || ($_REQUEST['address'] == "")
        || ($_REQUEST['city'] == "")
        || ($_REQUEST['state'] == "")
        || ($_REQUEST['zipcode'] == "")
        || ($_REQUEST['mobile'] == "")
        || ($_REQUEST['date'] == "")
        || ($_REQUEST['time'] == "")
        // || ($_FILES['image'] == "")
         || ($_REQUEST['description'] == "")) {
        $msg = '<div class="alert alert-danger">all fields are required</div>';
    } else {
        $name = $_REQUEST['name'];
        $request_status = $_REQUEST['request_status'];
        $email = $_REQUEST['email'];
        $address = $_REQUEST['address'];
        $city = $_REQUEST['city'];
        $state = $_REQUEST['state'];
        $zipcode = $_REQUEST['zipcode'];
        $mobile = $_REQUEST['mobile'];
        $date = $_REQUEST['date'];
        $time = $_REQUEST['time'];
        $imgname = $_FILES['image']['name'];
        $imgtmp = $_FILES['image']['tmp_name'];
        move_uploaded_file($imgtmp, '../assets/img/uploads/'. $imgname);
        $description = $_REQUEST['description'];
        $query = "INSERT INTO `submitrequest`(
             `name`,`request_status`, `email`, `address`, `city`, `state`, `zipcode`, `mobile`, `date`, `image`,`time`, `description`)
                 VALUES ('$name','$request_status','$email','$address','$city','$state','$zipcode','$mobile','$date','$imgname','$time','$description')"
        or die("connection error");

        if (mysqli_query($conn, $query)) {
            $id = mysqli_insert_id($conn);
            $msg = '<div  class="alert alert-success">Your Request is successfully Submitted!</div>';
            
            /*$_SESSION['msgnew'] = $msg;
            $_SESSION['id'] = $id;
            echo "<script> location.href='requesterinfo.php'</script>";*/

        } else {
            $msg = '<div class="alert alert-danger">Your Request is not send</div>';
        }

    }
}

?>
<div class="col-xl-8 col-md-12 order-xl-1">
    <div class="card bg-secondary shadow">
        <div class="card-header bg-white border-0">
            <div class="row align-items-center">
                <div class="col-8">
                    <h3 class="mb-0">Requester Info..</h3>
                </div>
                <div class="col-4 text-right">
                  <a href="requesterinfo.php" style="background-color: #B12B2E; color: white" class="btn btn-sm">View Request</a>
                </div>
            </div>

        </div>
        <div class="card-body">
            <?php if (isset($msg)) {
    echo $msg;
}?>
            <form method="post" enctype="multipart/form-data">
                <div class="pl-lg-4">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group focused">
                                <label class="form-control-label" for="input-username">Name</label>
                                <input type="text" id="input-username" class="form-control form-control-alternative"
                                    placeholder="atta.ur.rahman" value="" name="name">
                                    <input type="hidden" name="request_status" value="0">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-control-label" for="input-email">Email address</label>
                                <input type="email" id="input-email" class="form-control form-control-alternative"
                                    placeholder="atta@gmail.com" name="email">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Address -->
                <div class="pl-lg-4">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group focused">
                                <label class="form-control-label" for="input-address">Address</label>
                                <input id="input-address" class="form-control form-control-alternative"
                                    placeholder="islamabad E11/4 mehran coplex" type="text" name="address">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group focused">
                                <label class="form-control-label" for="input-city">City</label>
                                <input type="text" id="input-city" class="form-control form-control-alternative"
                                    placeholder="Isamabad" name="city">
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group focused">
                                <label class="form-control-label" for="input-country">state</label>
                                <input type="text" id="input-country" class="form-control form-control-alternative"
                                    placeholder="Pakistan" name="state">
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="form-control-label" for="input-country">Zip code</label>
                                <input type="number" id="input-postal-code"
                                    class="form-control form-control-alternative" placeholder="Postal code"
                                    name="zipcode">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="form-group focused">
                                <label class="form-control-label" for="input-username">Mobile</label>
                                <input type="text" id="input-username" class="form-control form-control-alternative"
                                    placeholder="mobile" name="mobile">
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="form-group">
                                <label class="form-control-label" for="input-email">Date</label>
                                <input type="date" class="form-control form-control-alternative" placeholder="1-1-2020"
                                    name="date">
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="form-group">
                                <label class="form-control-label" for="input-file">Image</label>
                                <input type="file" class="form-control form-control-alternative" placeholder="image"
                                    name="image">
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="form-group">
                                <label class="form-control-label">Time</label>
                                <input type="time" class="form-control form-control-alternative" placeholder="image"
                                    name="time">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Description -->
                <div class="pl-lg-4">
                    <div class="form-group focused">
                        <label class="form-control-label" for="input-file">Description</label>
                        <textarea rows="4" class="form-control form-control-alternative"
                            placeholder="A few words about your request" name="description"></textarea>
                    </div>
                </div>
                <div class="col-6 mx-2">
                    <input type="submit" name="submit" class="btn btn-md" style="background-color:#b12b2e;color:white"
                        value="submit">
                    <a href="#!" class="btn btn-md btn-success">Reset</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include_once 'includes/footer.php'?>
<?php
session_start();

include_once '../connection.php';
// define titel here
define('TITLE', 'Change Password');
//define active class
define('PAGE', 'changepassword');
//include header
include_once 'includes/header.php';

if (isset($_SESSION['is_login'])) {
    $email = $_SESSION['email'];
    $query = mysqli_query($conn, ("SELECT email,password FROM userregistration where email='".$_SESSION['email']."'"));
    if ($query == true) {
       $row = mysqli_fetch_assoc($query); 
            $email = $row['email'];
            $password = $row['password'];       
    }
} else {
    echo "<script>location.href='requesterLogin.php'</script>";
}
if (isset($_REQUEST['update'])) {
    if ($_REQUEST['password'] == "") {
        $msg = "<div class='alert alert-danger'>Your Password is empty!</div>";
    } else {
        $password = $_REQUEST['password'];
        $query = mysqli_query($conn,"UPDATE  userregistration SET password ='$password' where email ='$email'");
        if ($query == true) {

            echo '<script>location.href=changepassword.php</script>';
            $msg = '<div class="alert alert-success">Your Password is updated Successfully</div>';
        } else {
            $msg = '<div class="alert alert-danger">Your Password is not updated</div>';
        }
    }

}

?>
<br>
<div class="col-xl-8 order-xl-1">
    <div class="card bg-secondary shadow">
        <div class="card-header bg-white border-0">
            <div class="row align-items-center">
                <div class="col-8">
                    <h3 class="mb-0">My account</h3>
                </div>

            </div>
        </div>
        <div class="card-body">
            <form action="" method="POST">
                <!-- error mesage -->
                <?php if (isset($msg)) {
    echo $msg;
}?>
                <h6 class="heading-small text-muted mb-4 mx-4">User information</h6>
                <div class="pl-lg-4">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="form-control-label" for="input-email">Email
                                    address</label>
                                <input type="email" id="input-email" class="form-control form-control-alternative"
                                    placeholder="jesse@example.com" disabled value="<?php echo $email; ?>" name="email">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group focused">
                                <label class="form-control-label" for="input-username">Password</label>
                                <input type="password" id="input-password" class="form-control form-control-alternative"
                                    value="<?php echo $password; ?>" name="password">
                                <input type="checkbox" onclick="myFunction()"><small> <span style="color:#b12b2e"
                                        class=" font-weight-700">show password</span></small>
                            </div>
                        </div>
                        <div class="col-4">
                            <button type="Submit" style="background-color:#b12b2e;color:white" name="update"
                                class="btn btn-sm ">Update</button>
                        </div>
                    </div>
            </form>
        </div>
    </div>
</div>
<!-- include footer -->
<!-- the simple javascript code is use to show the password onlick button -->
<script>
function myFunction() {
    var x = document.getElementById("input-password");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
</script>

<?php include_once 'includes/footer.php';?>